# Estrutura dos Achados — PCSEC-PRIVESC

Este documento descreve em detalhe como o **PCSEC-PRIVESC** estrutura,
classifica e apresenta cada achado de auditoria, tanto no relatorio em texto
quanto no relatorio em JSON (`--json`).

## Campos de cada achado

Todo achado reportado pela ferramenta contem os seguintes campos:

| Campo | Descricao |
|---|---|
| **Verificacao / check** | Nome do modulo ou sub-verificacao que gerou o achado (ex.: "SUID / SGID Audit"). |
| **Alvo / target** | Caminho de arquivo, nome de processo, variavel ou configuracao especifica avaliada. |
| **Severidade / severity** | Um de: `INFO`, `LOW`, `MEDIUM`, `HIGH`, `CRITICAL`. |
| **Confianca / confidence** | Um de: `confirmed` (confirmadamente inseguro), `potential` (possivel vetor, requer validacao) ou `info` (informativo, requer investigacao manual). |
| **Descricao / description** | O que foi observado, em linguagem direta. |
| **Evidencia / evidence** | Dado minimo que sustenta o achado (ex.: permissoes do arquivo, resultado de um teste de escrita). Nunca inclui conteudo integral de arquivos sensiveis, senhas, tokens ou chaves. |
| **Motivo / reason** | Por que aquela severidade foi atribuida. |
| **Recomendacao / recommendation** | Acao sugerida para mitigar o risco. |
| **Limitacoes / limitations** | O que a verificacao **nao** cobre ou nao confirma, para deixar claro o escopo da analise. |

## Niveis de severidade

| Severidade | Quando e usada |
|---|---|
| **INFO** (Informativo) | Dado de contexto (ex.: versao do kernel, lista de processos root). Nao implica, por si so, um problema de seguranca. |
| **LOW** (Baixo) | Configuracao que merece atencao, mas com baixa probabilidade ou impacto de exploracao isolada (ex.: um binario SUID comum do sistema operacional). |
| **MEDIUM** (Medio) | Configuracao que pode facilitar um ataque, mas que tipicamente exige condicoes adicionais para ser explorada (ex.: diretorio home com permissao de escrita para outros). |
| **HIGH** (Alto) | Configuracao fortemente associada a tecnicas conhecidas de escalacao de privilegios (ex.: regra sudo NOPASSWD para um binario documentado como vetor de escalacao). |
| **CRITICAL** (Critico) | Configuracao que, isoladamente, ja representa um caminho direto e de alta confianca para comprometimento do sistema (ex.: `/etc/shadow` gravavel pelo usuario atual). |

## Niveis de confianca (confidence)

A ferramenta distingue explicitamente tres situacoes, para evitar
conclusoes precipitadas:

1. **`confirmed`** — Configuracao confirmadamente insegura. A propria
   verificacao testou diretamente a condicao (por exemplo, um teste real de
   permissao de escrita no arquivo, nao apenas a leitura das permissoes
   nominais).
2. **`potential`** — Possivel vetor de escalacao que precisa de validacao
   manual. A ferramenta encontrou um indicio (ex.: um binario presente em
   lista de referencia com bit SUID), mas a exploracao efetiva depende de
   fatores adicionais que a ferramenta nao confirma automaticamente (versao
   especifica do binario, argumentos liberados, contexto de uso, etc.).
3. **`info`** — Informacao que requer investigacao manual. Dados de
   contexto, sem uma afirmacao de risco especifica.

> A ferramenta **nunca declara que o usuario pode obter root** com base
> apenas em um achado isolado sem evidencia suficiente. Achados de alta
> severidade indicam uma condicao observavel e de alto risco teorico/pratico
> conhecido — a confirmacao final de exploracao e sempre responsabilidade do
> profissional que conduz a auditoria, dentro do escopo autorizado.

## Protecao de dados sensiveis nos relatorios

- Conteudo de arquivos como `/etc/shadow`, chaves privadas SSH ou arquivos de
  configuracao com credenciais **nunca** e reproduzido no relatorio.
- Quando uma variavel de ambiente ou configuracao com nome sugestivo de
  credencial e detectada, apenas sua **presenca** e reportada; o valor, se
  precisar ser citado, e sempre redigido (ex.: `abc...[REDACTED]`).
- Listagens de regras `sudo`, processos e arquivos sao truncadas quando muito
  extensas, para manter o relatorio legivel e evitar exposicao desnecessaria
  de dados operacionais do sistema.

## Formato do relatorio em texto

```
------------------------------------------------------------
Verificacao     : <nome da verificacao>
Alvo            : <caminho ou configuracao>
Severidade      : <SEVERIDADE> (<rotulo de confianca>)
Descricao       : <descricao do risco>
Evidencia       : <evidencia minima>
Motivo          : <motivo da classificacao>
Recomendacao    : <recomendacao de correcao>
Limitacoes      : <limitacoes da analise>
```

## Formato do relatorio em JSON (`--json`)

```json
{
  "tool": "PCSEC-PRIVESC",
  "name": "PabloCyberSec Linux Privilege Escalation",
  "version": "1.0.0",
  "author": "PabloCyberSec",
  "generated_at": "2026-01-01T12:00:00-03:00",
  "hostname": "exemplo-host",
  "scan_mode": "full",
  "summary": {
    "total": 36,
    "critical": 9,
    "high": 4,
    "medium": 0,
    "low": 13,
    "info": 10
  },
  "findings": [
    {
      "check": "Scheduled Tasks (Cron) Audit",
      "target": "/etc/cron.d",
      "severity": "CRITICAL",
      "confidence": "confirmed",
      "confidence_label": "Configuracao confirmadamente insegura",
      "description": "Diretorio de tarefas agendadas do sistema e gravavel pelo usuario atual.",
      "evidence": "Teste de permissao: diretorio gravavel = sim",
      "reason": "Scripts colocados neste diretorio sao tipicamente executados pelo cron do sistema com privilegios de root.",
      "recommendation": "Corrija a permissao do diretorio imediatamente para restringir escrita apenas a root.",
      "limitations": "Nenhum arquivo foi criado neste diretorio por esta ferramenta."
    }
  ]
}
```

Os valores de `summary` e os objetos em `findings` refletem exclusivamente o
resultado real daquela execucao — nao sao dados de exemplo fixos.
