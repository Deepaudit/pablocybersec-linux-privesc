# Instalacao — PCSEC-PRIVESC

Este documento detalha as formas suportadas de obter e instalar o
**PabloCyberSec Linux Privilege Escalation (PCSEC-PRIVESC)**.

## Requisitos previos

- Um sistema Linux com Bash 4.x ou superior.
- `curl` ou `wget` (para download) e, opcionalmente, `git` (para clonar o
  repositorio completo).
- Acesso de leitura/execucao ao diretorio onde o script sera salvo.
- Privilegios de root **nao sao necessarios** para as verificacoes basicas.

## Opcao 1 — Download apenas do script principal

Util quando voce quer apenas o `pcsec-privesc.sh` (execucao em modo
"tudo-em-um" ou aceitando que modulos ausentes serao pulados com aviso):

```bash
curl -fsSL "https://raw.githubusercontent.com/<SEU_USUARIO>/pablocybersec-linux-privesc/main/pcsec-privesc.sh" -o pcsec-privesc.sh
chmod +x pcsec-privesc.sh
./pcsec-privesc.sh --help
```

Ou com `wget`:

```bash
wget -q "https://raw.githubusercontent.com/<SEU_USUARIO>/pablocybersec-linux-privesc/main/pcsec-privesc.sh" -O pcsec-privesc.sh
chmod +x pcsec-privesc.sh
./pcsec-privesc.sh --help
```

> Troque `<SEU_USUARIO>` pelo dono real do repositorio publicado no GitHub.
> Este projeto nao fixa uma URL definitiva porque ela depende de onde voce
> efetivamente publicar o codigo.

### Por que apenas o script principal pode nao ser suficiente

O `pcsec-privesc.sh` carrega dinamicamente os arquivos dentro de `modules/`.
Se voce baixar somente o script principal, sem a pasta `modules/` ao lado
dele, a ferramenta ainda funciona, mas exibira avisos de "modulo ausente"
para cada modulo nao encontrado e pulara aquelas verificacoes. Para a
cobertura completa de auditoria, prefira a Opcao 2.

## Opcao 2 — Clonar o repositorio completo (recomendado)

```bash
git clone https://github.com/<SEU_USUARIO>/pablocybersec-linux-privesc.git
cd pablocybersec-linux-privesc
chmod +x pcsec-privesc.sh
./pcsec-privesc.sh --full
```

Isso garante que o script principal e todos os modulos em `modules/` estejam
presentes e corretamente referenciados.

## Verificando o conteudo antes de executar

Como boa pratica de seguranca, **sempre inspecione** um script antes de
executa-lo, especialmente se baixado de uma maquina diferente da sua rede de
confianca:

```bash
# Leia o conteudo do script
less pcsec-privesc.sh

# Gere o hash do arquivo baixado para comparar com um hash publicado
# (ex.: na pagina de releases do repositorio, se disponivel)
sha256sum pcsec-privesc.sh
```

Se o projeto publicar hashes oficiais de cada release, compare o hash
calculado localmente com o hash publicado antes de prosseguir.

## Opcao 3 — Execucao via pipe para o Bash (menos segura)

Alguns projetos divulgam instalacao via:

```bash
curl -fsSL "https://raw.githubusercontent.com/<SEU_USUARIO>/pablocybersec-linux-privesc/main/pcsec-privesc.sh" | bash
```

Isso funciona, mas **executa o codigo baixado imediatamente, sem qualquer
inspecao previa**. Se o repositorio remoto for comprometido, ou se o link
usado nao for o oficial, voce executaria codigo arbitrario na sua maquina sem
perceber.

**Recomendacao:** baixe o arquivo, leia-o (ou verifique seu hash) e só então
execute-o manualmente, como descrito nas Opcoes 1 e 2.

## Validando a instalacao

Apos instalar, confirme que a ferramenta esta funcional:

```bash
./pcsec-privesc.sh --version
./pcsec-privesc.sh --checks
./pcsec-privesc.sh --quick --no-color
```

Se desejar, execute a suite de testes basicos incluida no projeto:

```bash
chmod +x tests/test_basic.sh
./tests/test_basic.sh
```

## Desinstalacao

Como a ferramenta nao instala pacotes, nao cria servicos e nao grava nada
fora do diretorio de saida de relatorios que voce escolher, a "desinstalacao"
se resume a remover o diretorio onde o projeto foi clonado/baixado e,
opcionalmente, o diretorio de relatorios gerado (`pcsec-reports/` por
padrao):

```bash
rm -rf pablocybersec-linux-privesc/
rm -rf pcsec-reports/
```
