# Politica de Seguranca e Uso Responsavel — PCSEC-PRIVESC

## Escopo de uso autorizado

O **PabloCyberSec Linux Privilege Escalation (PCSEC-PRIVESC)** foi criado
exclusivamente para:

- Auditorias de seguranca em sistemas **proprios** ou sob **autorizacao
  explicita e formal** do responsavel pelo sistema (ex.: contrato de
  pentest, programa de bug bounty com escopo definido, laboratorio pessoal
  de estudo).
- Hardening e validacao continua de configuracoes de seguranca em ambientes
  corporativos, por equipes autorizadas (SecOps, SRE, administradores de
  sistema).
- Fins educacionais, em ambientes de laboratorio controlados.

**Nao utilize esta ferramenta contra sistemas, redes ou contas para os quais
voce nao possui autorizacao expressa.** Fazer isso pode violar leis locais,
nacionais ou internacionais relacionadas a acesso nao autorizado a sistemas
de computador.

## O que a ferramenta faz

- Executa **somente verificacoes locais de leitura** (permissoes,
  configuracoes, metadados de arquivos e processos).
- Classifica achados por severidade e nivel de confianca, com recomendacoes
  de correcao.
- Gera relatorios em texto e, opcionalmente, em JSON, salvos **apenas
  localmente**, no diretorio que voce especificar.

## O que a ferramenta NUNCA faz

- **Nao executa exploits** de nenhum tipo (kernel, aplicacao, sudo, etc.).
- **Nao tenta obter root automaticamente** nem realiza qualquer tentativa
  automatizada de escalacao de privilegios.
- **Nao modifica arquivos do sistema**, nao altera permissoes, nao cria
  usuarios, nao inicia/para servicos e nao altera tarefas agendadas.
- **Nao desativa mecanismos de seguranca** (firewall, SELinux/AppArmor,
  auditd, etc.).
- **Nao solicita nem armazena senhas** — a auditoria de `sudo`, por exemplo,
  e feita exclusivamente em modo nao interativo (`sudo -n -l`).
- **Nao transmite nenhum dado para servidores externos.** Toda a execucao e
  local; nao ha chamadas de rede embutidas na ferramenta.
- **Nao imprime segredos** (senhas, tokens, chaves privadas) nos relatorios;
  quando a presenca de algo sensivel precisa ser sinalizada, o valor e
  sempre redigido.
- **Nao instala pacotes automaticamente.** Quando uma dependencia opcional
  (ex.: `getcap`) esta ausente, a ferramenta apenas informa e segue em
  frente, pulando aquela verificacao especifica.

## Tratamento de dados sensiveis nos relatorios

- Verificacoes de arquivos sensiveis (`/etc/shadow`, chaves SSH, etc.)
  avaliam apenas **permissoes e metadados**, nunca o conteudo.
- Variaveis de ambiente com nomes sugestivos de credenciais sao reportadas
  apenas pela sua **presenca**; valores sao redigidos quando precisam ser
  citados no relatorio.
- Saidas de comandos potencialmente longas (ex.: `sudo -l`) sao truncadas no
  relatorio para reduzir exposicao desnecessaria de detalhes operacionais.

## Relatando problemas de seguranca no proprio projeto

Se voce identificar uma vulnerabilidade de seguranca no codigo do
**PCSEC-PRIVESC** em si (por exemplo, um caminho em que o proprio script
poderia expor dados sensiveis de forma nao intencional, ou um comportamento
que viole os principios descritos acima), por favor:

1. **Nao abra uma issue publica** descrevendo detalhes de exploracao antes de
   um contato inicial responsavel.
2. Entre em contato diretamente com o mantenedor do repositorio atraves dos
   canais indicados na pagina do projeto no GitHub (ex.: seguranca via
   contato privado do perfil `PabloCyberSec`, ou funcionalidade de
   *security advisory* do proprio GitHub, se habilitada no repositorio).
3. Descreva o problema, os passos para reproduzi-lo e, se possivel, uma
   sugestao de correcao.

Como este e um projeto de codigo aberto mantido de forma independente, nao
ha garantia de SLA para resposta, mas relatos responsaveis sao bem-vindos e
ajudam a manter a ferramenta confiavel para toda a comunidade que a utiliza
em auditorias legitimas.

## Isencao de responsabilidade

Esta ferramenta e fornecida "como esta", sem garantias de qualquer tipo (ver
[LICENSE](../LICENSE)). O uso indevido, nao autorizado ou ilegal desta
ferramenta e de inteira responsabilidade de quem a executa. Os autores e
colaboradores do projeto **PabloCyberSec Linux Privilege Escalation** nao se
responsabilizam por danos, perdas ou consequencias legais decorrentes do uso
inadequado desta ferramenta.
