# Guia de Uso — PCSEC-PRIVESC

Este documento descreve em detalhe como usar o
**PabloCyberSec Linux Privilege Escalation (PCSEC-PRIVESC)** no dia a dia de
uma auditoria autorizada.

## Antes de comecar

- Confirme que voce possui **autorizacao explicita** para auditar o sistema
  em questao.
- Rode a ferramenta como o usuario que faz mais sentido para o escopo da
  avaliacao: como usuario comum, para simular a visao de um atacante com
  acesso limitado; ou como root, para obter uma visao mais ampla do ambiente
  (a ferramenta avisa quando detecta que esta rodando como root, mas nunca
  usa isso para alterar o sistema).

## Execucao basica

```bash
./pcsec-privesc.sh
```

Sem argumentos, a ferramenta roda em modo `--full` (todas as verificacoes),
com cores habilitadas (se o terminal suportar) e salva os relatorios em
`./pcsec-reports/`.

## Modos de verificacao

### Modo rapido (`--quick`)

Executa um subconjunto menor e mais rapido de verificacoes — util para uma
primeira passada ou quando o tempo de execucao e uma restricao:

```bash
./pcsec-privesc.sh --quick
```

Modulos incluidos no modo rapido: System Enumeration, Sudo Configuration
Audit, SUID/SGID Audit e Kernel & Update Audit.

### Modo completo (`--full`)

Executa **todos** os modulos implementados:

```bash
./pcsec-privesc.sh --full
```

## Controlando a saida no terminal

### Desativar cores

Util para terminais sem suporte a ANSI, para redirecionar a saida para um
arquivo de log, ou por preferencia pessoal:

```bash
./pcsec-privesc.sh --full --no-color
```

A ferramenta tambem detecta automaticamente quando o terminal nao suporta
cores e desativa a formatacao ANSI nesses casos, mesmo sem a flag.

## Escolhendo onde salvar os relatorios

```bash
./pcsec-privesc.sh --full --output /tmp/auditoria-cliente-x
```

Se o diretorio nao existir, a ferramenta tenta cria-lo. Se nao for possivel
criar ou gravar no diretorio informado, um aviso e exibido e os relatorios
nao sao salvos em disco (a saida no terminal continua disponivel
normalmente).

## Gerando relatorio em JSON

Alem do relatorio em texto (sempre gerado), voce pode solicitar tambem um
relatorio estruturado em JSON — util para integracao com outras ferramentas,
dashboards ou pipelines de automacao de hardening:

```bash
./pcsec-privesc.sh --full --json --output /tmp/auditoria-cliente-x
```

Isso gera dois arquivos no diretorio de saida:

```
pcsec-privesc-report-<timestamp>.txt
pcsec-privesc-report-<timestamp>.json
```

## Listando as verificacoes disponiveis

```bash
./pcsec-privesc.sh --checks
```

Mostra o nome de cada modulo, uma descricao curta e o arquivo correspondente
em `modules/`.

## Combinando opcoes

As opcoes podem ser combinadas livremente:

```bash
./pcsec-privesc.sh --full --no-color --json --output /tmp/auditoria-$(hostname)-$(date +%Y%m%d)
```

## Interpretando a saida no terminal

Durante a execucao, cada modulo exibe:

```
[+] Nome do Modulo
   [SEVERIDADE] Nome da verificacao -> alvo/caminho afetado
```

Ao final, um resumo consolidado e exibido:

```
============================================================
  Audit completed.
============================================================

  Findings totais : 36
  Critical       : 9
  High           : 4
  Medium         : 0
  Low            : 13
  Informational  : 10
```

Os numeros refletem exclusivamente os achados **reais** daquela execucao, no
sistema auditado — nao sao valores fixos ou de exemplo.

## Interrompendo a execucao

A ferramenta trata `Ctrl+C` (SIGINT) e sinais de termino (SIGTERM) de forma
segura: nenhuma alteracao e feita no sistema, e uma mensagem de encerramento
e exibida antes de sair.

## Proximos passos apos a auditoria

1. Abra o relatorio texto (ou JSON) gerado no diretorio de saida.
2. Priorize a analise pelos achados **Critical** e **High**.
3. Para cada achado classificado como "possivel vetor — requer validacao
   manual", confirme manualmente antes de agir.
4. Aplique as recomendacoes de correcao sugeridas em cada achado,
   testando em ambiente controlado antes de aplicar em producao.
5. Repita a auditoria apos as correcoes para confirmar a mitigacao.

Veja tambem [`FINDINGS.md`](FINDINGS.md) para entender a estrutura detalhada
de cada achado e [`SECURITY.md`](SECURITY.md) para a politica de uso
responsavel e divulgacao de vulnerabilidades do proprio projeto.
